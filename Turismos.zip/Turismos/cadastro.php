<html>
			
			<head>
					<title> Cadastro de Usuário </title>
					
					<!-------------- css aplicando do html ------------------->
  <link rel="stylesheet" type="text/css" href="css/style.css">
					<!---------------------------------------------------------> 

		</head>

<body>
		
		
			<div class="container">
											
											<section id="content">
											
			<form method="POST" action="registro.php">	
			
							<label></label><input type="text" name="nome" placeholder="Seu nome" id="nome"><br>
							<label></label><input type="text" name="endereco" placeholder="Seu endereço" id="endereço"><br>
							<label></label><input type="text" name="rg" placeholder="Seu RG" id="rg"><br>
							<label></label><input type="text" name="cpf" placeholder="Seu CPF" id="cpf"><br>
							<label></label><input type="text" name="e-mail" placeholder="Seu E-mail" id="e-mail"><br>
                                                        <label></label><input type="text" name="login" placeholder="Seu login" id="e-mail"><br>
							<label></label><input type="password" name="senha" placeholder="Sua senha" id="senha"><br>
							<label></label><input type="password" name="repsenha" placeholder="Confirme sua senha" id="repsenha"><br>
							<input type="submit" value="Cadastro" a href="registrar.php" />&nbsp;
			</form>
			
	
		</div>
			
</body>


</html>
